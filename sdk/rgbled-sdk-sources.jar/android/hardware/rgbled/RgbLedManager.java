/*
 * Copyright (C) 2026 The LineageOS Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package android.hardware.rgbled;

import android.Manifest;
import android.annotation.ColorInt;
import android.annotation.IntDef;
import android.annotation.IntRange;
import android.annotation.NonNull;
import android.annotation.Nullable;
import android.annotation.RequiresPermission;
import android.annotation.SystemService;
import android.content.Context;
import android.os.RemoteException;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Controls the notification RGB LED: per-channel brightness, solid colors,
 * hardware blinking and kernel LED triggers such as {@link #TRIGGER_HEARTBEAT}.
 * <p>
 * Obtain an instance with {@code context.getSystemService(Context.RGB_LED_SERVICE)};
 * it is {@code null} on devices without an RGB LED HAL. Methods that change the LED
 * require {@link android.Manifest.permission#CONTROL_RGB_LED}.
 * <p>
 * The system lights (battery, notifications) keep using the same LED, so a state
 * set here is replaced the next time one of them changes.
 */
@SystemService(Context.RGB_LED_SERVICE)
public final class RgbLedManager {
    /** Red channel. */
    public static final int CHANNEL_RED = 0;
    /** Green channel. */
    public static final int CHANNEL_GREEN = 1;
    /** Blue channel. */
    public static final int CHANNEL_BLUE = 2;

    /** @hide */
    @IntDef(prefix = { "CHANNEL_" }, value = { CHANNEL_RED, CHANNEL_GREEN, CHANNEL_BLUE })
    @Retention(RetentionPolicy.SOURCE)
    public @interface Channel {}

    /** Detaches any kernel trigger from a channel. */
    public static final String TRIGGER_NONE = "none";
    /** Kernel trigger that pulses the channel like a heartbeat, faster under load. */
    public static final String TRIGGER_HEARTBEAT = "heartbeat";
    /** Kernel trigger that blinks the channel with a software timer. */
    public static final String TRIGGER_TIMER = "timer";

    /** Shortest supported on-time for {@link #setBlink}, in milliseconds. */
    public static final int MIN_BLINK_ON_MS = 50;
    /** Longest supported on- or off-time for {@link #setBlink}, in milliseconds. */
    public static final int MAX_BLINK_MS = 10000;

    private final IRgbLedService mService;

    /** @hide */
    public RgbLedManager(Context context, IRgbLedService service) {
        mService = service;
    }

    /** Returns whether the RGB LED hardware service is reachable. */
    public boolean isAvailable() {
        try {
            return mService.isAvailable();
        } catch (RemoteException e) {
            throw e.rethrowFromSystemServer();
        }
    }

    /**
     * Sets one channel's brightness, leaving the other channels unchanged.
     * A brightness of 0 switches the channel off.
     *
     * @return whether the hardware accepted the change
     */
    @RequiresPermission(Manifest.permission.CONTROL_RGB_LED)
    public boolean setChannel(@Channel int channel, @IntRange(from = 0, to = 255) int brightness) {
        try {
            return mService.setChannel(channel, brightness);
        } catch (RemoteException e) {
            throw e.rethrowFromSystemServer();
        }
    }

    /**
     * Shows a solid color. Each component of {@code color} is scaled by
     * {@code brightness}; alpha is ignored.
     *
     * @return whether the hardware accepted the change
     */
    @RequiresPermission(Manifest.permission.CONTROL_RGB_LED)
    public boolean setColor(@ColorInt int color, @IntRange(from = 0, to = 255) int brightness) {
        try {
            return mService.setColor(color, brightness);
        } catch (RemoteException e) {
            throw e.rethrowFromSystemServer();
        }
    }

    /**
     * Blinks a color using the LED controller's hardware pattern generator.
     *
     * @param onMs time lit, {@link #MIN_BLINK_ON_MS} to {@link #MAX_BLINK_MS}
     * @param offMs time dark, 0 to {@link #MAX_BLINK_MS}; 0 means solid
     * @return whether the hardware accepted the change
     */
    @RequiresPermission(Manifest.permission.CONTROL_RGB_LED)
    public boolean setBlink(@ColorInt int color, @IntRange(from = 0, to = 255) int brightness,
            @IntRange(from = MIN_BLINK_ON_MS, to = MAX_BLINK_MS) int onMs,
            @IntRange(from = 0, to = MAX_BLINK_MS) int offMs) {
        try {
            return mService.setBlink(color, brightness, onMs, offMs);
        } catch (RemoteException e) {
            throw e.rethrowFromSystemServer();
        }
    }

    /** Returns the kernel LED triggers supported by the RGB channels. */
    public @NonNull String[] getSupportedTriggers() {
        try {
            String[] triggers = mService.getSupportedTriggers();
            return triggers != null ? triggers : new String[0];
        } catch (RemoteException e) {
            throw e.rethrowFromSystemServer();
        }
    }

    /**
     * Attaches a kernel trigger, one of {@link #getSupportedTriggers()}, to a channel.
     * Use {@link #TRIGGER_NONE} to detach.
     *
     * @return whether the trigger is supported and was attached
     */
    @RequiresPermission(Manifest.permission.CONTROL_RGB_LED)
    public boolean setTrigger(@Channel int channel, @NonNull String trigger) {
        try {
            return mService.setTrigger(channel, trigger);
        } catch (RemoteException e) {
            throw e.rethrowFromSystemServer();
        }
    }

    /** Returns the trigger attached to a channel, or {@code null} if it cannot be read. */
    public @Nullable String getTrigger(@Channel int channel) {
        try {
            return mService.getTrigger(channel);
        } catch (RemoteException e) {
            throw e.rethrowFromSystemServer();
        }
    }

    /** Returns a channel's current brightness (0-255), or -1 if it cannot be read. */
    public int getBrightness(@Channel int channel) {
        try {
            return mService.getBrightness(channel);
        } catch (RemoteException e) {
            throw e.rethrowFromSystemServer();
        }
    }

    /**
     * Detaches all triggers and switches every channel off.
     *
     * @return whether the hardware accepted the change
     */
    @RequiresPermission(Manifest.permission.CONTROL_RGB_LED)
    public boolean turnOff() {
        try {
            return mService.turnOff();
        } catch (RemoteException e) {
            throw e.rethrowFromSystemServer();
        }
    }
}
